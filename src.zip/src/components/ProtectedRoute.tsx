import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Navigation } from './Navigation';

export function ProtectedRoute() {
    const { isAuthenticated, authInitialized } = useAuth();

    if (!authInitialized && !isAuthenticated) {
        return <div style={{ padding: '2rem', textAlign: 'center' }}>Cargando la sesión...</div>;
    }

    if (!isAuthenticated) {
        return <Navigate to="/welcome" replace />;
    }

    return (
        <>
            <Navigation />
            <main className="main-content">
                <Outlet />
            </main>
        </>
    );
}
