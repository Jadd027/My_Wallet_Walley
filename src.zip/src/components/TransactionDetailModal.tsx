import React from 'react';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { X, ArrowUpRight, ArrowDownRight, Tag, Calendar, AlignLeft, ArrowRightLeft } from 'lucide-react';
import type { Transaction, Category } from '../types';
import { formatCOP } from '../utils/currency';
import './TransactionDetailModal.css';

interface TransactionDetailModalProps {
    transaction: Transaction;
    category?: Category;
    onClose: () => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({ transaction, category, onClose }) => {
    const isIncome = transaction.type === 'income';

    return (
        <div className="modal-overlay animate-fade-in" onClick={onClose}>
            <div className="modal-container transaction-detail-modal" onClick={e => e.stopPropagation()}>
                <div className="modal-header">
                    <h2>Detalle del Movimiento</h2>
                    <button className="btn-icon" onClick={onClose}>
                        <X size={24} />
                    </button>
                </div>

                <div className="modal-content">
                    <div className="transaction-header-info">
                        <div className="transaction-icon-large" style={{ backgroundColor: `${category?.color}20`, color: category?.color }}>
                            {isIncome ? <ArrowUpRight size={32} /> : <ArrowDownRight size={32} />}
                        </div>
                        <h3>{transaction.title}</h3>
                        <div className={`transaction-amount-large ${transaction.type}`}>
                            {isIncome ? '+' : '-'}{formatCOP(transaction.amount)}
                        </div>
                    </div>

                    <div className="transaction-details-grid">
                        <div className="detail-item">
                            <Tag size={18} className="text-muted" />
                            <div className="detail-text">
                                <span className="text-muted text-sm">Categoría</span>
                                <span>{category?.name || 'Sin Categoría'}</span>
                            </div>
                        </div>

                        <div className="detail-item">
                            <ArrowRightLeft size={18} className="text-muted" />
                            <div className="detail-text">
                                <span className="text-muted text-sm">Tipo</span>
                                <span className="capitalize">{transaction.type === 'income' ? 'Ingreso' : 'Gasto'}</span>
                            </div>
                        </div>

                        <div className="detail-item">
                            <Calendar size={18} className="text-muted" />
                            <div className="detail-text">
                                <span className="text-muted text-sm">Fecha y Hora</span>
                                <span>{format(parseISO(transaction.date), "dd 'de' MMMM, yyyy HH:mm", { locale: es })}</span>
                            </div>
                        </div>

                        {transaction.notes && (
                            <div className="detail-item full-width">
                                <AlignLeft size={18} className="text-muted" />
                                <div className="detail-text">
                                    <span className="text-muted text-sm">Notas</span>
                                    <p className="notes-content">{transaction.notes}</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
