import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Receipt, User, PlusCircle, Tags } from 'lucide-react';
import './Navigation.css';

export const Navigation: React.FC = () => {
    const navItems = [
        { path: '/', icon: <LayoutDashboard size={24} />, label: 'Inicio' },
        { path: '/transactions', icon: <Receipt size={24} />, label: 'Movimientos' },
        { path: '/add', icon: <PlusCircle size={28} className="add-icon" />, label: 'Añadir', isMain: true },
        { path: '/categories', icon: <Tags size={24} />, label: 'Categorías' },
        { path: '/profile', icon: <User size={24} />, label: 'Perfil' },
    ];

    return (
        <>
            {/* Desktop Sidebar */}
            <aside className="sidebar">
                <div className="sidebar-header">
                    <div className="logo-icon">MW</div>
                    <h2>My Wallet</h2>
                </div>
                <nav className="sidebar-nav">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''} ${item.isMain ? 'main-action' : ''}`}
                        >
                            <span className="nav-icon">{item.icon}</span>
                            <span className="nav-label">{item.label}</span>
                        </NavLink>
                    ))}
                </nav>
            </aside>

            {/* Mobile Bottom Navigation */}
            <nav className="bottom-nav">
                {navItems.map((item) => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        className={({ isActive }) => `bottom-nav-item ${isActive ? 'active' : ''} ${item.isMain ? 'main-action' : ''}`}
                    >
                        <span className="nav-icon">{item.icon}</span>
                        <span className="nav-label">{item.label}</span>
                    </NavLink>
                ))}
            </nav>
        </>
    );
};
