import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';

interface User {
    id: string;
    name: string;
    email: string;
}

interface AuthContextType {
    user: User | null;
    login: (email: string, password: string) => Promise<void>;
    register: (name: string, email: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
    isAuthenticated: boolean;
    authInitialized: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [authInitialized, setAuthInitialized] = useState(false);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
            try {
                if (firebaseUser) {
                    const userRef = doc(db, 'users', firebaseUser.uid);
                    const userSnapshot = await getDoc(userRef);

                    if (userSnapshot.exists()) {
                        const userData = userSnapshot.data();
                        setUser({
                            id: firebaseUser.uid,
                            name: userData.name || firebaseUser.displayName || 'Usuario',
                            email: userData.email || firebaseUser.email || ''
                        });
                    } else {
                        const name = firebaseUser.displayName || 'Usuario';
                        const email = firebaseUser.email || '';
                        await setDoc(userRef, { name, email });
                        setUser({ id: firebaseUser.uid, name, email });
                    }
                } else {
                    setUser(null);
                }
            } catch (error) {
                console.error('Error en onAuthStateChanged handler:', error);
                setUser(null);
            } finally {
                setAuthInitialized(true);
            }
        });

        return unsubscribe;
    }, []);

    const login = async (email: string, password: string) => {
        const credentials = await signInWithEmailAndPassword(auth, email, password);
        setUser({
            id: credentials.user.uid,
            name: credentials.user.displayName || 'Usuario',
            email: credentials.user.email || email
        });
        setAuthInitialized(true);
    };

    const register = async (name: string, email: string, password: string) => {
        const credentials = await createUserWithEmailAndPassword(auth, email, password);
        const userRef = doc(db, 'users', credentials.user.uid);
        await setDoc(userRef, { name, email });
        setUser({ id: credentials.user.uid, name, email });
        setAuthInitialized(true);
    };

    const logout = async () => {
        await signOut(auth);
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated: !!user, authInitialized }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
