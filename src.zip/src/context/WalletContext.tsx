import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import {
    collection,
    query,
    orderBy,
    onSnapshot,
    addDoc,
    setDoc,
    doc,
    updateDoc,
    deleteDoc
} from 'firebase/firestore';
import type { Transaction, Category, WalletState } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../firebase';
import { useAuth } from './AuthContext';

interface WalletContextType extends WalletState {
    addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => Promise<void>;
    updateTransaction: (id: string, transaction: Partial<Omit<Transaction, 'id' | 'createdAt'>>) => Promise<void>;
    deleteTransaction: (id: string) => Promise<void>;
    addCategory: (category: Omit<Category, 'id'>) => Promise<void>;
    updateCategory: (id: string, updates: Partial<Omit<Category, 'id'>>) => Promise<void>;
    deleteCategory: (id: string) => Promise<void>;
    setFilters: (filters: WalletState['filters']) => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [filters, setFiltersState] = useState<WalletState['filters']>({
        type: 'all'
    });

    useEffect(() => {
        if (!user) {
            setTransactions([]);
            setCategories([]);
            return;
        }

        const transactionsRef = collection(db, 'users', user.id, 'transactions');
        const categoriesRef = collection(db, 'users', user.id, 'categories');

        const unsubscribeTransactions = onSnapshot(
            query(transactionsRef, orderBy('createdAt', 'desc')),
            (snapshot) => {
                setTransactions(snapshot.docs.map((doc) => {
                    const { id: _id, ...transactionData } = doc.data() as Transaction;
                    return { id: doc.id, ...transactionData };
                }));
            }
        );

        const unsubscribeCategories = onSnapshot(categoriesRef, (snapshot) => {
            const remoteCategories = snapshot.docs.map((doc) => {
                const { id: _id, ...categoryData } = doc.data() as Category;
                return { id: doc.id, ...categoryData };
            });

            setCategories(remoteCategories);
        });

        return () => {
            unsubscribeTransactions();
            unsubscribeCategories();
        };
    }, [user]);

    const addTransaction = async (transaction: Omit<Transaction, 'id' | 'createdAt'>) => {
        if (!user) return;
        const transactionsRef = collection(db, 'users', user.id, 'transactions');
        await addDoc(transactionsRef, {
            ...transaction,
            createdAt: new Date().toISOString()
        });
    };

    const updateTransaction = async (id: string, updates: Partial<Omit<Transaction, 'id' | 'createdAt'>>) => {
        if (!user) return;
        const transactionRef = doc(db, 'users', user.id, 'transactions', id);
        await updateDoc(transactionRef, updates);
    };

    const deleteTransaction = async (id: string) => {
        if (!user) return;
        const transactionRef = doc(db, 'users', user.id, 'transactions', id);
        await deleteDoc(transactionRef);
    };

    const addCategory = async (category: Omit<Category, 'id'>) => {
        if (!user) return;
        const categoryId = uuidv4();
        const categoryRef = doc(db, 'users', user.id, 'categories', categoryId);
        await setDoc(categoryRef, { ...category, id: categoryId });
    };

    const updateCategory = async (id: string, updates: Partial<Omit<Category, 'id'>>) => {
        if (!user) return;
        const categoryRef = doc(db, 'users', user.id, 'categories', id);
        await updateDoc(categoryRef, updates);
    };

    const deleteCategory = async (id: string) => {
        if (!user) return;
        const categoryRef = doc(db, 'users', user.id, 'categories', id);
        await deleteDoc(categoryRef);
    };

    const setFilters = (newFilters: WalletState['filters']) => {
        setFiltersState((prev) => ({ ...prev, ...newFilters }));
    };

    return (
        <WalletContext.Provider value={{
            transactions,
            categories,
            filters,
            addTransaction,
            updateTransaction,
            deleteTransaction,
            addCategory,
            updateCategory,
            deleteCategory,
            setFilters
        }}>
            {children}
        </WalletContext.Provider>
    );
};

export const useWallet = () => {
    const context = useContext(WalletContext);
    if (!context) {
        throw new Error('useWallet must be used within a WalletProvider');
    }
    return context;
};
