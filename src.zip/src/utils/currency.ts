export const formatCOP = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        maximumFractionDigits: 0,
    }).format(amount);
};

export const formatCOPInput = (value: string) => {
    const normalized = value
        .replace(/\./g, '')
        .replace(/,/g, '.')
        .replace(/[^\d.]/g, '');

    const parts = normalized.split('.');
    const integerPart = parts.shift() || '';
    const decimalPart = parts.join('').slice(0, 2);

    const formattedInteger = integerPart
        ? new Intl.NumberFormat('es-CO').format(Number(integerPart))
        : '';

    return decimalPart ? `${formattedInteger},${decimalPart}` : formattedInteger;
};

export const parseCOPInput = (value: string) => {
    const normalized = value
        .replace(/\./g, '')
        .replace(/,/g, '.')
        .replace(/[^\d.]/g, '');

    return normalized ? Number(normalized) : 0;
};
