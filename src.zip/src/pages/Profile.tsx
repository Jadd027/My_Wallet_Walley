import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { User, LogOut, Settings, Bell, Shield } from 'lucide-react';
import './Profile.css';

export function Profile() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = async () => {
        await logout();
        navigate('/welcome');
    };

    return (
        <div className="profile-container animate-fade-in">
            <h1 className="page-title">Perfil y Ajustes</h1>

            <div className="profile-header card">
                <div className="profile-avatar">
                    <User size={40} />
                </div>
                <div className="profile-info">
                    <h2>{user?.name || 'Usuario'}</h2>
                    <p className="text-muted">{user?.email || 'usuario@correo.com'}</p>
                </div>
            </div>

            <div className="settings-section">
                <h3 className="section-title">Ajustes de la cuenta</h3>

                <div className="settings-list card">
                    <button className="settings-item">
                        <div className="settings-item-icon bg-primary-light text-primary">
                            <User size={20} />
                        </div>
                        <div className="settings-item-content">
                            <span>Editar Perfil</span>
                            <p className="text-muted">Actualiza tu información personal</p>
                        </div>
                    </button>

                    <button className="settings-item">
                        <div className="settings-item-icon bg-warning-light text-warning">
                            <Bell size={20} />
                        </div>
                        <div className="settings-item-content">
                            <span>Notificaciones</span>
                            <p className="text-muted">Configura tus alertas</p>
                        </div>
                    </button>

                    <button className="settings-item">
                        <div className="settings-item-icon bg-success-light text-success">
                            <Shield size={20} />
                        </div>
                        <div className="settings-item-content">
                            <span>Seguridad</span>
                            <p className="text-muted">Contraseña y métodos de acceso</p>
                        </div>
                    </button>

                    <button className="settings-item">
                        <div className="settings-item-icon" style={{ backgroundColor: 'rgba(107, 114, 128, 0.1)', color: 'var(--text-muted)' }}>
                            <Settings size={20} />
                        </div>
                        <div className="settings-item-content">
                            <span>Preferencias de la App</span>
                            <p className="text-muted">Tema, moneda e idioma</p>
                        </div>
                    </button>
                </div>
            </div>

            <button className="btn btn-danger btn-logout w-100" onClick={handleLogout}>
                <LogOut size={20} />
                <span>Cerrar Sesión</span>
            </button>
        </div>
    );
}
