import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus } from 'lucide-react';
import './Auth.css';
import { useAuth } from '../context/AuthContext';

export function Auth() {
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { login, register } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            if (isLogin) {
                await login(email, password);
            } else {
                await register(name || 'Usuario', email, password);
            }
            navigate('/');
        } catch (err) {
            console.error('Auth error:', err);
            const authCode = (err as any)?.code;
            let message = 'Ocurrió un error al iniciar sesión o crear la cuenta. Verifica tus datos.';

            if (authCode === 'auth/invalid-credential') {
                message = 'Credenciales inválidas. Revisa tu correo y contraseña.';
            } else if (authCode === 'auth/email-already-in-use') {
                message = 'El correo ya está en uso. Intenta iniciar sesión o usa otro correo.';
            } else if (authCode === 'auth/wrong-password') {
                message = 'Contraseña incorrecta. Intenta de nuevo.';
            } else if (authCode === 'auth/user-not-found') {
                message = 'No existe una cuenta con ese correo.';
            } else if (err instanceof Error) {
                message = err.message;
            }

            setError(message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-container animate-fade-in">
            <div className="auth-card">
                <h1 className="auth-title">
                    {isLogin ? 'Iniciar Sesión' : 'Crear Cuenta'}
                </h1>
                <p className="auth-subtitle">
                    {isLogin
                        ? 'Bienvenido de nuevo a My Wallet Walley'
                        : 'Comienza a organizar tus finanzas hoy'}
                </p>

                <form onSubmit={handleSubmit} className="auth-form">
                    {!isLogin && (
                        <div className="form-group">
                            <label htmlFor="name">Nombre</label>
                            <input
                                id="name"
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="Ingresa tu nombre"
                                required
                            />
                        </div>
                    )}

                    <div className="form-group">
                        <label htmlFor="email">Correo Electrónico</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="tu@correo.com"
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Contraseña</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && <div className="auth-error">{error}</div>}

                    <button
                        type="submit"
                        className="btn btn-primary w-100 flex-center"
                        disabled={loading}
                    >
                        {isLogin ? <LogIn size={18} /> : <UserPlus size={18} />}
                        <span style={{ marginLeft: '8px' }}>
                            {isLogin ? 'Ingresar' : 'Registrarse'}
                        </span>
                    </button>
                </form>

                <div className="auth-toggle">
                    <span>
                        {isLogin ? '¿No tienes cuenta?' : '¿Ya tienes cuenta?'}
                    </span>
                    <button
                        type="button"
                        className="btn-text"
                        onClick={() => setIsLogin(!isLogin)}
                    >
                        {isLogin ? 'Regístrate aquí' : 'Inicia Sesión'}
                    </button>
                </div>
            </div>
        </div>
    );
}
