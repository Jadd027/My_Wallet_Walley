import React, { useState } from 'react';
import { useWallet } from '../context/WalletContext';
import type { Category, TransactionType } from '../types';
import { Plus, Edit2, Trash2, X, Check } from 'lucide-react';
import './Categories.css';

export const Categories: React.FC = () => {
    const { categories, addCategory, updateCategory, deleteCategory } = useWallet();
    const [isEditing, setIsEditing] = useState<string | null>(null);
    const [isAdding, setIsAdding] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // Form state for adding/editing
    const [formData, setFormData] = useState({
        name: '',
        type: 'expense' as TransactionType,
        color: '#6366f1',
        icon: 'tag'
    });

    const resetForm = () => {
        setFormData({ name: '', type: 'expense', color: '#6366f1', icon: 'tag' });
        setIsEditing(null);
        setIsAdding(false);
        setError('');
        setLoading(false);
    };

    const handleEdit = (category: Category) => {
        setFormData({
            name: category.name,
            type: category.type,
            color: category.color,
            icon: category.icon
        });
        setIsEditing(category.id);
        setIsAdding(false);
    };

    const handleSave = async () => {
        if (!formData.name.trim()) return;

        setLoading(true);
        setError('');
        try {
            if (isEditing) {
                await updateCategory(isEditing, formData);
            } else if (isAdding) {
                await addCategory(formData);
            }
            resetForm();
        } catch (err: any) {
            console.error('Error al guardar categoría:', err);
            setError('Error al guardar la categoría. Revisa tus permisos o conexión.');
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (window.confirm('¿Seguro que deseas eliminar esta categoría?')) {
            try {
                await deleteCategory(id);
            } catch (err: any) {
                console.error('Error al eliminar categoría:', err);
                alert('No se pudo eliminar la categoría. Verifica tus permisos o conexión.');
            }
        }
    };

    return (
        <div className="categories-page animate-fade-in">
            <header className="page-header">
                <div>
                    <h1 className="page-title">Categorías</h1>
                    <p className="text-muted">Administra tus categorías de ingresos y gastos</p>
                </div>
                {!isAdding && !isEditing && (
                    <button className="btn btn-primary new-category-btn" onClick={() => setIsAdding(true)}>
                        <Plus size={20} />
                        Nueva
                    </button>
                )}
            </header>

            {(isAdding || isEditing) && (
                <div className="card category-form-card animate-slide-up">
                    <h3>{isEditing ? 'Editar Categoría' : 'Nueva Categoría'}</h3>
                    {error && (
                        <div style={{
                            marginTop: '12px',
                            padding: '8px 12px',
                            backgroundColor: 'var(--danger-bg)',
                            color: 'var(--danger)',
                            border: '1px solid var(--danger)',
                            borderRadius: 'var(--radius-md)',
                            fontSize: '0.85rem',
                            textAlign: 'center'
                        }}>
                            {error}
                        </div>
                    )}
                    <div className="form-group mt-4">
                        <label className="form-label">Nombre</label>
                        <input
                            type="text"
                            value={formData.name}
                            onChange={e => setFormData({ ...formData, name: e.target.value })}
                            placeholder="Ej. Compras"
                            className="form-control"
                        />
                    </div>
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Tipo</label>
                            <select
                                className="form-control"
                                value={formData.type}
                                onChange={e => setFormData({ ...formData, type: e.target.value as TransactionType })}
                            >
                                <option value="expense">Gasto</option>
                                <option value="income">Ingreso</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Color</label>
                            <input
                                type="color"
                                value={formData.color}
                                onChange={e => setFormData({ ...formData, color: e.target.value })}
                                className="form-control color-picker"
                            />
                        </div>
                    </div>
                    <div className="form-actions">
                        <button className="btn btn-outline" onClick={resetForm} disabled={loading}>
                            <X size={18} /> Cancelar
                        </button>
                        <button className="btn btn-primary" onClick={handleSave} disabled={loading}>
                            <Check size={18} /> {loading ? 'Guardando...' : 'Guardar'}
                        </button>
                    </div>
                </div>
            )}

            <div className="categories-list">
                {categories.map((category) => (
                    <div key={category.id} className="card category-card">
                        <div className="category-info">
                            <div className="category-icon" style={{ backgroundColor: category.color + '20', color: category.color }}>
                                {/* Icon placeholder - in a real app, render dynamically based on category.icon */}
                                <div style={{ width: 24, height: 24, borderRadius: '50%', backgroundColor: category.color }}></div>
                            </div>
                            <div>
                                <h4>{category.name}</h4>
                                <span className={`type-badge ${category.type}`}>
                                    {category.type === 'income' ? 'Ingreso' : 'Gasto'}
                                </span>
                            </div>
                        </div>
                        <div className="category-actions">
                            <button className="icon-btn edit-btn" onClick={() => handleEdit(category)}>
                                <Edit2 size={18} />
                            </button>
                             <button className="icon-btn delete-btn" onClick={() => handleDelete(category.id)}>
                                <Trash2 size={18} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
