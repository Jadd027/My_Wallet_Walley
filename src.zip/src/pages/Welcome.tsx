import { useNavigate } from 'react-router-dom';
import { Wallet, ArrowRight } from 'lucide-react';
import './Welcome.css';

export function Welcome() {
    const navigate = useNavigate();

    return (
        <div className="welcome-container animate-fade-in">
            <div className="welcome-content">
                <div className="logo-container">
                    <div className="logo-circle">
                        <Wallet size={48} className="logo-icon" />
                    </div>
                    <h1 className="app-title">My Wallet Walley</h1>
                    <p className="app-subtitle">Tu asistente financiero personal</p>
                </div>

                <div className="features-list">
                    <div className="feature-item">
                        <div className="feature-icon bg-success-light text-success">
                            ✓
                        </div>
                        <span>Controla tus ingresos y gastos</span>
                    </div>
                    <div className="feature-item">
                        <div className="feature-icon bg-primary-light text-primary">
                            ✓
                        </div>
                        <span>Organiza por categorías</span>
                    </div>
                    <div className="feature-item">
                        <div className="feature-icon bg-warning-light text-warning">
                            ✓
                        </div>
                        <span>Alcanza tus metas financieras</span>
                    </div>
                </div>

                <div className="welcome-actions">
                    <button
                        className="btn btn-primary btn-large w-100"
                        onClick={() => navigate('/auth')}
                    >
                        Comenzar
                        <ArrowRight size={20} />
                    </button>
                </div>
            </div>
        </div>
    );
}
