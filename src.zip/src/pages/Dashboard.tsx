import React, { useMemo } from 'react';
import { useWallet } from '../context/WalletContext';
import { ArrowUpRight, ArrowDownRight, Wallet } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { formatCOP } from '../utils/currency';
import './Dashboard.css';

export const Dashboard: React.FC = () => {
    const { transactions, categories } = useWallet();

    const now = new Date();

    const { totalBalance, totalIncome, totalExpense, monthlyIncome, monthlyExpense } = useMemo(() => {
        return transactions.reduce((acc, curr) => {
            const transactionDate = parseISO(curr.date);
            const sameMonth = transactionDate.getFullYear() === now.getFullYear() && transactionDate.getMonth() === now.getMonth();

            if (curr.type === 'income') {
                acc.totalIncome += curr.amount;
                acc.totalBalance += curr.amount;
                if (sameMonth) {
                    acc.monthlyIncome += curr.amount;
                }
            } else {
                acc.totalExpense += curr.amount;
                acc.totalBalance -= curr.amount;
                if (sameMonth) {
                    acc.monthlyExpense += curr.amount;
                }
            }
            return acc;
        }, { totalBalance: 0, totalIncome: 0, totalExpense: 0, monthlyIncome: 0, monthlyExpense: 0 });
    }, [transactions, now]);

    const monthlySavings = monthlyIncome - monthlyExpense;

    const expensesByCategory = useMemo(() => {
        const expenses = transactions.filter(t => t.type === 'expense');
        const grouped = expenses.reduce((acc, curr) => {
            acc[curr.categoryId] = (acc[curr.categoryId] || 0) + curr.amount;
            return acc;
        }, {} as Record<string, number>);

        return Object.keys(grouped).map(catId => {
            const category = categories.find(c => c.id === catId);
            return {
                name: category?.name || 'Otro',
                value: grouped[catId],
                color: category?.color || '#ccc'
            };
        }).sort((a, b) => b.value - a.value);
    }, [transactions, categories]);

    const recentTransactions = transactions.slice(0, 5);


    return (
        <div className="dashboard animate-fade-in">
            <header className="dashboard-header mb-6">
                <div>
                    <h1 className="mb-0">Hola de nuevo 👋</h1>
                    <p className="text-muted">Aquí está el resumen de tus finanzas.</p>
                </div>
            </header>

            <div className="balance-cards grid mb-6">
                <div className="card balance-card total-card">
                    <div className="card-icon"><Wallet size={24} /></div>
                    <h3>Saldo Total</h3>
                    <h2>{formatCOP(totalBalance)}</h2>
                </div>

                <div className="card balance-card income-card">
                    <div className="card-icon success-icon"><ArrowUpRight size={24} /></div>
                    <h3>Ingresos</h3>
                    <h2>{formatCOP(totalIncome)}</h2>
                </div>

                <div className="card balance-card expense-card">
                    <div className="card-icon danger-icon"><ArrowDownRight size={24} /></div>
                    <h3>Gastos</h3>
                    <h2>{formatCOP(totalExpense)}</h2>
                </div>

                <div className="card balance-card monthly-card">
                    <div className="card-icon info-icon"><ArrowDownRight size={24} /></div>
                    <h3>Gastos Mensuales</h3>
                    <h2>{formatCOP(monthlyExpense)}</h2>
                    <p className="text-muted">Mes actual</p>
                </div>

                <div className="card balance-card savings-card">
                    <div className="card-icon success-icon"><ArrowUpRight size={24} /></div>
                    <h3>Ahorro</h3>
                    <h2>{formatCOP(monthlySavings)}</h2>
                    <p className="text-muted">Ingresos - gastos del mes</p>
                </div>
            </div>

            <div className="dashboard-grid grid">
                <div className="card">
                    <div className="flex justify-between items-center mb-4">
                        <h2>Movimientos Recientes</h2>
                        <Link to="/transactions" className="text-primary text-sm font-medium">Ver todos</Link>
                    </div>

                    {recentTransactions.length > 0 ? (
                        <div className="transaction-list">
                            {recentTransactions.map(t => {
                                const category = categories.find(c => c.id === t.categoryId);
                                return (
                                    <div key={t.id} className="transaction-item">
                                        <div className="transaction-icon" style={{ backgroundColor: `${category?.color}20`, color: category?.color }}>
                                            {/* En una app real usaríamos iconos dinámicos según el string */}
                                            {t.type === 'income' ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
                                        </div>
                                        <div className="transaction-info">
                                            <h4>{t.title}</h4>
                                            <p className="text-sm text-muted">{category?.name} • {format(parseISO(t.date), "d MMM yyyy", { locale: es })}</p>
                                        </div>
                                        <div className={`transaction-amount ${t.type}`}>
                                            {t.type === 'income' ? '+' : '-'}{formatCOP(t.amount)}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <div className="empty-state">
                            <p className="text-muted">No tienes movimientos recientes.</p>
                            <Link to="/add" className="btn btn-primary mt-4">Añadir movimiento</Link>
                        </div>
                    )}
                </div>

                <div className="card">
                    <h2>Gastos por Categoría</h2>
                    {expensesByCategory.length > 0 ? (
                        <div className="chart-container">
                            <ResponsiveContainer width="100%" height={250}>
                                <PieChart>
                                    <Pie
                                        data={expensesByCategory}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={60}
                                        outerRadius={80}
                                        paddingAngle={5}
                                        dataKey="value"
                                    >
                                        {expensesByCategory.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip formatter={(value) => formatCOP(Number(value) || 0)} />
                                </PieChart>
                            </ResponsiveContainer>
                            <div className="chart-legend">
                                {expensesByCategory.map((entry, idx) => (
                                    <div key={idx} className="legend-item">
                                        <span className="legend-color" style={{ backgroundColor: entry.color }}></span>
                                        <span className="legend-label text-sm">{entry.name}</span>
                                        <span className="legend-value text-sm font-medium">{formatCOP(entry.value)}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="empty-state">
                            <p className="text-muted">No hay gastos para mostrar.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
