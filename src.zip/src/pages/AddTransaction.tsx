import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../context/WalletContext';
import { ArrowUpRight, ArrowDownRight, Tag, FileText, DollarSign } from 'lucide-react';
import { formatCOPInput, parseCOPInput } from '../utils/currency';
import './AddTransaction.css';

export const AddTransaction: React.FC = () => {
    const navigate = useNavigate();
    const { categories, addTransaction } = useWallet();

    const [type, setType] = useState<'income' | 'expense'>('expense');
    const [amount, setAmount] = useState('');
    const [title, setTitle] = useState('');
    const [categoryId, setCategoryId] = useState('');
    const [date, setDate] = useState(() => new Date().toISOString().substring(0, 16)); // YYYY-MM-DDThh:mm
    const [notes, setNotes] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const filteredCategories = categories.filter(c => c.type === type);
    // select first by default if not selected
    React.useEffect(() => {
        if (filteredCategories.length > 0 && !filteredCategories.find(c => c.id === categoryId)) {
            setCategoryId(filteredCategories[0].id);
        }
    }, [type, filteredCategories, categoryId]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!amount || !title || !categoryId || !date) return;

        setLoading(true);
        setError('');
        try {
            await addTransaction({
                type,
                amount: parseCOPInput(amount),
                title,
                categoryId,
                date: new Date(date).toISOString(),
                notes: notes || undefined
            });
            navigate('/transactions');
        } catch (err: any) {
            console.error('Error al guardar movimiento:', err);
            setError('Error al guardar el movimiento. Revisa las reglas de seguridad o conexión de Firebase.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="add-transaction-page animate-fade-in">
            <header className="page-header mb-6">
                <h1>Añadir Movimiento</h1>
                <p className="text-muted">Registra un nuevo ingreso o gasto.</p>
            </header>

            <div className="card">
                <div className="type-selector mb-6">
                    <button
                        className={`type-btn expense ${type === 'expense' ? 'active' : ''}`}
                        onClick={() => setType('expense')}
                    >
                        <ArrowDownRight size={20} />
                        Gasto
                    </button>
                    <button
                        className={`type-btn income ${type === 'income' ? 'active' : ''}`}
                        onClick={() => setType('income')}
                    >
                        <ArrowUpRight size={20} />
                        Ingreso
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="add-form">
                    {error && (
                        <div style={{
                            marginBottom: '16px',
                            padding: '12px',
                            backgroundColor: 'var(--danger-bg)',
                            color: 'var(--danger)',
                            border: '1px solid var(--danger)',
                            borderRadius: 'var(--radius-md)',
                            fontSize: '0.9rem',
                            textAlign: 'center'
                        }}>
                            {error}
                        </div>
                    )}
                    <div className="form-group">
                        <label className="form-label text-sm">Monto</label>
                        <div className="input-with-icon">
                            <DollarSign size={20} className="input-icon" />
                            <input
                                type="text"
                                inputMode="decimal"
                                className="form-control amount-input"
                                placeholder="0"
                                value={amount}
                                onChange={e => setAmount(formatCOPInput(e.target.value))}
                                required
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label text-sm">Título / Descripción</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Ej. Compra de supermercado"
                            value={title}
                            onChange={e => setTitle(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label className="form-label text-sm">Categoría</label>
                        <div className="input-with-icon">
                            <Tag size={20} className="input-icon" />
                            <select
                                className="form-control"
                                value={categoryId}
                                onChange={e => setCategoryId(e.target.value)}
                                required
                            >
                                <option value="" disabled>Selecciona una categoría</option>
                                {filteredCategories.map(c => (
                                    <option key={c.id} value={c.id}>{c.name}</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label text-sm">Fecha y Hora</label>
                        <input
                            type="datetime-local"
                            className="form-control"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group mb-6">
                        <label className="form-label text-sm">Notas (Opcional)</label>
                        <div className="input-with-icon">
                            <FileText size={20} className="input-icon" style={{ alignSelf: 'flex-start', marginTop: '14px' }} />
                            <textarea
                                className="form-control"
                                placeholder="Detalles adicionales..."
                                rows={3}
                                value={notes}
                                onChange={e => setNotes(e.target.value)}
                            ></textarea>
                        </div>
                    </div>

                    <div className="form-actions">
                        <button type="button" className="btn btn-outline" onClick={() => navigate(-1)} disabled={loading}>Cancelar</button>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? 'Guardando...' : 'Guardar Movimiento'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
