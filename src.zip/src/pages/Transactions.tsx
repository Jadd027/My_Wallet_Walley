import React, { useState } from 'react';
import { useWallet } from '../context/WalletContext';
import { ArrowUpRight, ArrowDownRight, Trash2, Filter } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatCOP } from '../utils/currency';
import { TransactionDetailModal } from '../components/TransactionDetailModal';
import type { Transaction } from '../types';
import './Transactions.css';

export const Transactions: React.FC = () => {
    const { transactions, categories, deleteTransaction } = useWallet();
    const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
    const [startDate, setStartDate] = useState<string>('');
    const [endDate, setEndDate] = useState<string>('');
    const [categoryId, setCategoryId] = useState<string>('all');
    const [minValue, setMinValue] = useState<number | ''>('');
    const [maxValue, setMaxValue] = useState<number | ''>('');
    const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

    const handleDeleteTransaction = async (id: string) => {
        try {
            await deleteTransaction(id);
        } catch (err: any) {
            console.error('Error al eliminar movimiento:', err);
            alert('No se pudo eliminar el movimiento. Verifica tus permisos o conexión.');
        }
    };

    const filteredTransactions = transactions.filter(t => {
        if (filterType !== 'all' && t.type !== filterType) return false;
        if (categoryId !== 'all' && t.categoryId !== categoryId) return false;
        if (startDate && t.date < startDate) return false;
        if (endDate && t.date > endDate + 'T23:59:59') return false;
        if (minValue !== '' && t.amount < minValue) return false;
        if (maxValue !== '' && t.amount > maxValue) return false;
        return true;
    });


    return (
        <div className="transactions-page animate-fade-in">
            <header className="page-header mb-6">
                <div className="flex justify-between items-center">
                    <h1>Movimientos</h1>
                </div>
                <p className="text-muted">Historial completo de tus ingresos y gastos.</p>
            </header>

            <div className="filters-section card mb-6">
                <div className="section-title">
                    <Filter size={16} className="text-muted" />
                    <h3>Filtros</h3>
                </div>
                <div className="advanced-filters">
                    <div className="filter-chips">
                        <button
                            className={`chip ${filterType === 'all' ? 'active' : ''}`}
                            onClick={() => setFilterType('all')}
                        >
                            Todos
                        </button>
                        <button
                            className={`chip income ${filterType === 'income' ? 'active' : ''}`}
                            onClick={() => setFilterType('income')}
                        >
                            Ingresos
                        </button>
                        <button
                            className={`chip expense ${filterType === 'expense' ? 'active' : ''}`}
                            onClick={() => setFilterType('expense')}
                        >
                            Gastos
                        </button>
                    </div>

                    <div className="filters-divider"></div>

                    <div className="filter-grid">
                        <div className="filter-group">
                            <label>Categoría</label>
                            <select className="form-input" value={categoryId} onChange={e => setCategoryId(e.target.value)}>
                                <option value="all">Todas</option>
                                {categories.filter(c => filterType === 'all' || c.type === filterType).map(c => (
                                    <option key={c.id} value={c.id}>{c.name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="filter-group">
                            <label>Desde</label>
                            <input type="date" className="form-input" value={startDate} onChange={e => setStartDate(e.target.value)} />
                        </div>
                        <div className="filter-group">
                            <label>Hasta</label>
                            <input type="date" className="form-input" value={endDate} onChange={e => setEndDate(e.target.value)} />
                        </div>
                        <div className="filter-group">
                            <label>Mínimo ($)</label>
                            <input type="number" className="form-input" placeholder="0" value={minValue} onChange={e => setMinValue(e.target.value ? Number(e.target.value) : '')} />
                        </div>
                        <div className="filter-group">
                            <label>Máximo ($)</label>
                            <input type="number" className="form-input" placeholder="0" value={maxValue} onChange={e => setMaxValue(e.target.value ? Number(e.target.value) : '')} />
                        </div>
                    </div>
                </div>
            </div>

            <div className="card">
                {filteredTransactions.length > 0 ? (
                    <div className="transaction-list">
                        {filteredTransactions.map(t => {
                            const category = categories.find(c => c.id === t.categoryId);
                            return (
                                <div key={t.id} className="transaction-item detailed clickable" onClick={() => setSelectedTransaction(t)}>
                                    <div className="transaction-icon" style={{ backgroundColor: `${category?.color}20`, color: category?.color }}>
                                        {t.type === 'income' ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
                                    </div>

                                    <div className="transaction-info">
                                        <h4>{t.title}</h4>
                                        <p className="text-sm text-muted">
                                            {category?.name} • {format(parseISO(t.date), "dd/MM/yyyy HH:mm", { locale: es })}
                                        </p>
                                        {t.notes && <p className="text-sm text-muted notes-text">Nota: {t.notes}</p>}
                                    </div>

                                    <div className="transaction-actions flex flex-col items-end gap-2">
                                        <div className={`transaction-amount ${t.type}`}>
                                            {t.type === 'income' ? '+' : '-'}{formatCOP(t.amount)}
                                        </div>
                                        <button
                                            className="btn-icon delete-btn"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (window.confirm('¿Seguro que deseas eliminar este movimiento?')) {
                                                    handleDeleteTransaction(t.id);
                                                }
                                            }}
                                            title="Eliminar"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="empty-state">
                        <p className="text-muted">No se encontraron movimientos con los filtros actuales.</p>
                    </div>
                )}
            </div>

            {selectedTransaction && (
                <TransactionDetailModal
                    transaction={selectedTransaction}
                    category={categories.find(c => c.id === selectedTransaction.categoryId)}
                    onClose={() => setSelectedTransaction(null)}
                />
            )}
        </div>
    );
};
