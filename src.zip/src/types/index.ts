export type TransactionType = 'income' | 'expense';

export interface Category {
    id: string;
    name: string;
    type: TransactionType;
    color: string;
    icon: string;
}

export interface Transaction {
    id: string;
    title: string;
    amount: number;
    type: TransactionType;
    categoryId: string;
    date: string; // ISO String
    notes?: string;
    createdAt: string; // ISO String
}

export interface WalletState {
    transactions: Transaction[];
    categories: Category[];
    filters: {
        startDate?: string;
        endDate?: string;
        categoryId?: string;
        type?: TransactionType | 'all';
    };
}
