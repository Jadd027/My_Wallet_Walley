package com.mywallet.walley;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
